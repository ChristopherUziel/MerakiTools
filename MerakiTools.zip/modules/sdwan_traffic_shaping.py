import json
import requests

from meraki_api import (
    obtener_networks,
    obtener_organizaciones,
    obtener_traffic_shaping_rules,
    obtener_vpn_exclusions_organizacion,
    actualizar_traffic_shaping_rules,
)

from modules.alta_evento import (
    seleccionar_network,
    seleccionar_organizacion,
)

from modules.politicas import (
    seleccionar_varios_elementos,
)


def sincronizar_sdwan_traffic_shaping() -> None:
    """
    Selecciona una Network modelo
    Consulta por separado traffic rules y vpn exclussion por si alguna no esta disponible
    """

    organizacion_modelo = seleccionar_organizacion("modelo")

    network_modelo = seleccionar_network(
        organization_id=organizacion_modelo["id"],
        descripcion="modelo",
    )

    print("\nConsultando configuración de " f"{network_modelo['name']}...\n")

    traffic_shaping_rules = None
    vpn_exclusions = None

    ###################
    # TRAFFIC SHAPING RULES

    try:
        traffic_shaping_rules = obtener_traffic_shaping_rules(network_modelo["id"])

        print("✓ Traffic Shaping Rules disponibles.")

    except requests.HTTPError as error:
        detalle = error.response.text if error.response is not None else str(error)

        print("⚠ Traffic Shaping Rules no disponibles.")
        print(f"  Motivo: {detalle}")

    except requests.RequestException as error:
        print("⚠ No fue posible consultar " "Traffic Shaping Rules.")
        print(f"  Error: {error}")

    #################
    # VPN EXCLUSIONS

    try:
        respuesta_vpn = obtener_vpn_exclusions_organizacion(organizacion_modelo["id"])

        for item in respuesta_vpn.get("items", []):
            if item.get("networkId") == network_modelo["id"]:
                vpn_exclusions = item
                break

        if vpn_exclusions is None:
            print("⚠ La Network modelo no tiene " "VPN Exclusions disponibles.")
        else:
            print("✓ VPN Exclusions disponibles.")

    except requests.HTTPError as error:
        detalle = error.response.text if error.response is not None else str(error)

        print("⚠ VPN Exclusions no disponibles.")
        print(f"  Motivo: {detalle}")

    except requests.RequestException as error:
        print("⚠ No fue posible consultar " "VPN Exclusions.")
        print(f"  Error: {error}")

    ############
    # Respuesta

    if traffic_shaping_rules is None and vpn_exclusions is None:
        print(
            "\nLa Network modelo no tiene ninguna "
            "configuración compatible para clonar.\n"
        )
        return

    networks_destino = seleccionar_networks_destino_sdwan(
        network_modelo_id=network_modelo["id"],
    )

    resultados = analizar_sdwan_destino(
        traffic_shaping_modelo=traffic_shaping_rules,
        vpn_exclusions_modelo=vpn_exclusions,
        networks_destino=networks_destino,
    )

    mostrar_analisis_sdwan(resultados)

    ejecutar_sincronizacion_sdwan(resultados)


def preparar_vpn_exclusion(
    vpn_exclusion: dict,
) -> dict:
    """
    prepara las exclusiones de vpn de la network modelo
    """

    return {
        "custom": vpn_exclusion.get(  ###limpia el diccionario recibido con las claves buscadas
            "custom",
            [],
        ),
        "majorApplications": vpn_exclusion.get(
            "majorApplications",
            [],
        ),
    }


def preparar_traffic_shaping_rules(
    traffic_shaping_rules: dict,
) -> dict:
    """
    Prepara las traffic shaping rules de la network modelo
    """

    return {
        "defaultRulesEnabled": traffic_shaping_rules.get(
            "defaultRulesEnabled",
            False,
        ),
        "rules": traffic_shaping_rules.get(
            "rules",
            [],
        ),
    }


def seleccionar_networks_destino_sdwan(
    network_modelo_id: str,
) -> list[dict]:
    """
    Permite seleccionar una o varias org y networks destino
    """

    organizaciones = obtener_organizaciones()

    organizaciones_ordenadas = sorted(
        organizaciones,
        key=lambda organizacion: organizacion.get(
            "name",
            "",
        ).lower(),
    )

    print("\n=== ORGANIZACIONES DESTINO ===\n")

    for indice, organizacion in enumerate(
        organizaciones_ordenadas,
        start=1,
    ):
        print(f"{indice}. " f"{organizacion.get('name', 'Sin nombre')}")

    entrada = input(
        "\nSelecciona una o varias organizaciones "
        "separadas por comas, o escribe 'todas':\n> "
    )

    organizaciones_seleccionadas = seleccionar_varios_elementos(
        elementos=organizaciones_ordenadas,
        entrada=entrada,
    )

    networks_destino = []

    for organizacion in organizaciones_seleccionadas:

        organization_id = organizacion["id"]
        organization_name = organizacion.get(
            "name",
            "Sin nombre",
        )

        networks = obtener_networks(organization_id)

        # Solo Networks con MX / appliance.
        # También excluimos la Network modelo.
        networks_disponibles = [
            network
            for network in networks
            if (network.get("id") != network_modelo_id)
            and (
                "appliance"
                in network.get(
                    "productTypes",
                    [],
                )
            )
        ]

        networks_ordenadas = sorted(
            networks_disponibles,
            key=lambda network: network.get(
                "name",
                "",
            ).lower(),
        )

        print("\n" + "=" * 60)
        print(f" ORGANIZACIÓN: {organization_name}")
        print("=" * 60)

        if not networks_ordenadas:
            print("\nNo tiene Networks con MX disponibles.")
            continue

        for indice, network in enumerate(
            networks_ordenadas,
            start=1,
        ):
            print(f"{indice}. " f"{network.get('name', 'Sin nombre')}")

        entrada_networks = input(
            "\nSelecciona una o varias Networks, " "'todas' o 'ninguna':\n> "
        )

        networks_seleccionadas = seleccionar_varios_elementos(
            elementos=networks_ordenadas,
            entrada=entrada_networks,
            permitir_ninguna=True,
        )

        for network in networks_seleccionadas:
            networks_destino.append(
                {
                    "organization_id": organization_id,
                    "organization_name": organization_name,
                    "network_id": network["id"],
                    "network_name": network.get(
                        "name",
                        "Sin nombre",
                    ),
                }
            )

    if not networks_destino:
        raise ValueError("No seleccionaste ninguna Network destino.")

    return networks_destino


def analizar_sdwan_destino(
    traffic_shaping_modelo: dict | None,
    vpn_exclusions_modelo: dict | None,
    networks_destino: list[dict],
) -> list[dict]:
    """
    Analiza las Networks destino sin realizar cambios
    """

    resultados = []

    vpn_por_organizacion = {}

    for destino in networks_destino:

        print(
            "\nAnalizando "
            f"{destino['organization_name']} | "
            f"{destino['network_name']}..."
        )

        resultado = {
            "organization_id": destino["organization_id"],
            "organization_name": destino["organization_name"],
            "network_id": destino["network_id"],
            "network_name": destino["network_name"],
            "traffic_shaping": {
                "accion": "Omitir",
                "motivo": None,
            },
            "vpn_exclusions": {
                "accion": "Omitir",
                "motivo": None,
            },
        }

        # =====================================
        # TRAFFIC SHAPING RULES
        # =====================================

        if traffic_shaping_modelo is not None:

            try:
                traffic_destino = obtener_traffic_shaping_rules(destino["network_id"])

                modelo_preparado = preparar_traffic_shaping_rules(
                    traffic_shaping_modelo
                )

                destino_preparado = preparar_traffic_shaping_rules(traffic_destino)

                if modelo_preparado == destino_preparado:
                    accion = "Sin cambios"
                else:
                    accion = "Actualizar"

                resultado["traffic_shaping"] = {
                    "accion": accion,
                    "motivo": None,
                    "configuracion": modelo_preparado,
                }

            except requests.HTTPError as error:

                detalle = (
                    error.response.text if error.response is not None else str(error)
                )

                resultado["traffic_shaping"] = {
                    "accion": "Omitir",
                    "motivo": detalle,
                }

            except requests.RequestException as error:

                resultado["traffic_shaping"] = {
                    "accion": "Omitir",
                    "motivo": str(error),
                }

        else:
            resultado["traffic_shaping"]["motivo"] = (
                "La Network modelo no proporcionó " "Traffic Shaping Rules."
            )

        ##############
        # VPN EXCLUSIONS

        if vpn_exclusions_modelo is not None:

            try:
                organization_id = destino["organization_id"]

                # Solo consultamos una vez cada organización.
                if organization_id not in vpn_por_organizacion:
                    vpn_por_organizacion[organization_id] = (
                        obtener_vpn_exclusions_organizacion(organization_id)
                    )

                respuesta_vpn = vpn_por_organizacion[organization_id]

                vpn_destino = None

                for item in respuesta_vpn.get(
                    "items",
                    [],
                ):
                    if item.get("networkId") == destino["network_id"]:
                        vpn_destino = item
                        break

                modelo_preparado = preparar_vpn_exclusion(vpn_exclusions_modelo)

                # Si la Network aparece pero no tiene reglas se convierte en una lista vacia
                if vpn_destino is None:
                    destino_preparado = {
                        "custom": [],
                        "majorApplications": [],
                    }

                else:
                    destino_preparado = preparar_vpn_exclusion(vpn_destino)

                if modelo_preparado == destino_preparado:
                    accion = "Sin cambios"
                else:
                    accion = "Actualizar"

                resultado["vpn_exclusions"] = {
                    "accion": accion,
                    "motivo": None,
                    "configuracion": modelo_preparado,
                }

            except requests.HTTPError as error:

                detalle = (
                    error.response.text if error.response is not None else str(error)
                )

                resultado["vpn_exclusions"] = {
                    "accion": "Omitir",
                    "motivo": detalle,
                }

            except requests.RequestException as error:

                resultado["vpn_exclusions"] = {
                    "accion": "Omitir",
                    "motivo": str(error),
                }

        else:
            resultado["vpn_exclusions"]["motivo"] = (
                "La Network modelo no proporcionó " "VPN Exclusions."
            )

        resultados.append(resultado)

    return resultados


def mostrar_analisis_sdwan(
    resultados: list[dict],
) -> None:
    """
    Muestra qué se haría en cada Network.
    """

    print("\n=== ANÁLISIS SD-WAN / " "TRAFFIC SHAPING ===\n")

    for resultado in resultados:

        print(f"{resultado['organization_name']} | " f"{resultado['network_name']}")

        traffic = resultado["traffic_shaping"]

        print("  Traffic Shaping Rules: " f"{traffic['accion']}")

        if traffic.get("motivo"):
            print(f"    Motivo: {traffic['motivo']}")

        vpn = resultado["vpn_exclusions"]

        print("  VPN Exclusions: " f"{vpn['accion']}")

        if vpn.get("motivo"):
            print(f"    Motivo: {vpn['motivo']}")

        print()


def ejecutar_sincronizacion_sdwan(
        resultados: list[dict],
        network_id: str,
) -> None:

    for resultado in resultados:

        traffic = resultado["traffic_shaping"]

        if traffic.get("accion") == "Actualizar":
            actualizar_traffic_shaping_rules(network_id, traffic)

        if traffic.get("accion") == "Sin cambios":

        if traffic.get("accion") == "Omitir":

            print(f"No se pudo actualizar - " traffic.get("motivo"))
