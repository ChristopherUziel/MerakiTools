import json
import requests
from meraki_api import (
    obtener_networks,
    obtener_organizaciones,
    obtener_politicas_grupo,
)
from modules.alta_evento import (
    seleccionar_network,
    seleccionar_organizacion,
)


def seleccionar_varios_elementos(
    elementos: list[dict],
    entrada: str,
    permitir_ninguna: bool = False,
) -> list[dict]:
    """
    Convierte la seleccion en una lista
    """

    entrada = entrada.strip().lower()

    if entrada == "todas":
        return elementos.copy()

    if permitir_ninguna and entrada == "ninguna":
        return []

    seleccionados = []

    for valor in entrada.split(","):
        valor = valor.strip()

        if not valor:
            continue

        if not valor.isdigit():
            raise ValueError(f"'{valor}' no es una opción válida.")

        indice = int(valor) - 1

        if indice < 0 or indice >= len(elementos):
            raise ValueError(f"La opción {valor} no existe.")

        elemento = elementos[indice]

        if elemento not in seleccionados:
            seleccionados.append(elemento)

    if not seleccionados:
        raise ValueError("No seleccionaste ninguna opción válida.")

    return seleccionados


def seleccionar_politicas(
    politicas: list[dict],
) -> list[dict]:
    """
    Permite seleccionar una o varias Group Policies.
    """

    if not politicas:
        return []

    politicas_ordenadas = sorted(
        politicas,
        key=lambda politica: politica.get(
            "name",
            "",
        ).lower(),
    )

    print("\nGroup Policies disponibles:\n")

    for indice, politica in enumerate(
        politicas_ordenadas,
        start=1,
    ):
        nombre = politica.get(
            "name",
            "Sin nombre",
        )

        policy_id = politica.get(
            "groupPolicyId",
            "Sin ID",
        )

        print(f"{indice}. {nombre} " f"| ID: {policy_id}")

    entrada = input(
        "\nSelecciona una o varias políticas "
        "separadas por comas, o escribe 'todas':\n> "
    ).strip()

    if entrada.lower() == "todas":
        return politicas_ordenadas

    opciones = []

    for valor in entrada.split(","):
        valor = valor.strip()

        if not valor:
            continue

        if not valor.isdigit():
            raise ValueError(f"'{valor}' no es una opción válida.")

        indice = int(valor) - 1

        if indice < 0 or indice >= len(politicas_ordenadas):
            raise ValueError(f"La opción {valor} no existe.")

        politica = politicas_ordenadas[indice]

        if politica not in opciones:
            opciones.append(politica)

    if not opciones:
        raise ValueError("No seleccionaste ninguna política.")

    return opciones


def mostrar_politicas_seleccionadas(
    politicas: list[dict],
) -> None:
    """
    Muestra las políticas modelo seleccionadas
    y su configuración completa.
    """

    print("\n=== POLÍTICAS MODELO SELECCIONADAS ===\n")

    for politica in politicas:
        print(
            f"- {politica.get('name', 'Sin nombre')} "
            f"| ID: "
            f"{politica.get('groupPolicyId', 'Sin ID')}"
        )

        print("\nConfiguración devuelta por Meraki:\n")

        print(
            json.dumps(
                politica,
                indent=4,
                ensure_ascii=False,
            )
        )

        print("\n" + "-" * 70 + "\n")


def seleccionar_networks_destino(
    network_modelo_id: str,
) -> list[dict]:
    """
    Permite seleccionar una o varias organizaciones
    y después una o varias Networks de cada una.

    La Network modelo se excluye automáticamente
    """

    organizaciones = obtener_organizaciones()

    if not organizaciones:
        raise ValueError("No se encontraron organizaciones disponibles.")

    organizaciones_ordenadas = sorted(
        organizaciones,
        key=lambda organizacion: organizacion.get(
            "name",
            "",
        ).lower(),
    )

    print("\n=== ORGANIZACIONES DESTINO ===\n")

    for indice, organizacion in enumerate(
        organizaciones_ordenadas,
        start=1,
    ):
        print(f"{indice}. " f"{organizacion.get('name', 'Sin nombre')}")

    entrada = input(
        "\nSelecciona una o varias organizaciones "
        "separadas por comas, o escribe 'todas':\n> "
    )

    organizaciones_seleccionadas = seleccionar_varios_elementos(
        elementos=organizaciones_ordenadas,
        entrada=entrada,
    )

    networks_destino = []

    for organizacion in organizaciones_seleccionadas:
        organization_id = organizacion["id"]
        organization_name = organizacion.get(
            "name",
            "Sin nombre",
        )

        networks = obtener_networks(organization_id)

        # Evitamos mostrar la Network modelo como destino.
        networks_disponibles = [
            network for network in networks if network.get("id") != network_modelo_id
        ]

        networks_ordenadas = sorted(
            networks_disponibles,
            key=lambda network: network.get(
                "name",
                "",
            ).lower(),
        )

        print("\n" + "=" * 60)
        print(f" ORGANIZACIÓN: {organization_name}")
        print("=" * 60)

        if not networks_ordenadas:
            print("\nNo tiene Networks disponibles " "para usarse como destino.")
            continue

        for indice, network in enumerate(
            networks_ordenadas,
            start=1,
        ):
            print(f"{indice}. " f"{network.get('name', 'Sin nombre')}")

        entrada_networks = input(
            "\nSelecciona una o varias Networks, " "'todas' o 'ninguna':\n> "
        )

        networks_seleccionadas = seleccionar_varios_elementos(
            elementos=networks_ordenadas,
            entrada=entrada_networks,
            permitir_ninguna=True,
        )

        for network in networks_seleccionadas:
            networks_destino.append(
                {
                    "organization_id": organization_id,
                    "organization_name": organization_name,
                    "network_id": network["id"],
                    "network_name": network.get(
                        "name",
                        "Sin nombre",
                    ),
                }
            )

    if not networks_destino:
        raise ValueError("No seleccionaste ninguna Network destino.")

    return networks_destino


def mostrar_networks_destino(
    networks_destino: list[dict],
) -> None:
    """
    Muestra las Networks que recibiran las políticas
    """

    print("\n=== NETWORKS DESTINO SELECCIONADAS ===\n")

    for destino in networks_destino:
        print(f"- {destino['organization_name']} " f"| {destino['network_name']}")

    print(f"\nTotal de Networks destino: " f"{len(networks_destino)}")


def sincronizar_politicas() -> None:
    """
    Primera etapa

    Selecciona una Network modelo y permite escoger
    las Group Policies que posteriormente se copiarán.
    """

    print("\n" + "=" * 50)
    print(" SINCRONIZACIÓN DE GROUP POLICIES")
    print("=" * 50)

    try:
        organizacion_modelo = seleccionar_organizacion("modelo")

        network_modelo = seleccionar_network(
            organization_id=organizacion_modelo["id"],
            descripcion="modelo",
        )

        print("\nConsultando políticas de " f"{network_modelo['name']}...")

        politicas = obtener_politicas_grupo(network_modelo["id"])

        if not politicas:
            print("\nLa Network modelo no tiene " "Group Policies disponibles.\n")
            return

        politicas_seleccionadas = seleccionar_politicas(politicas)

        mostrar_politicas_seleccionadas(politicas_seleccionadas)

        networks_destino = seleccionar_networks_destino(
            network_modelo_id=network_modelo["id"],
        )

        mostrar_networks_destino(networks_destino)

        print(
            "\nEsta etapa es únicamente de consulta. "
            "Todavía no se realizaron cambios.\n"
        )

    except ValueError as error:
        print(f"\nError de selección: {error}\n")

    except requests.RequestException as error:
        print("\nNo fue posible consultar las políticas " f"en Meraki:\n{error}\n")
